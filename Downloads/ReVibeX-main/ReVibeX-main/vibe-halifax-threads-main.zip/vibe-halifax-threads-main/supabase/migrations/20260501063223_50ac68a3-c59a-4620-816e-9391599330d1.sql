-- THREADS
CREATE TABLE public.threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL,
  seller_id UUID NOT NULL,
  listing_title TEXT NOT NULL,
  last_message TEXT,
  last_message_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT threads_no_self_chat CHECK (buyer_id <> seller_id),
  CONSTRAINT threads_unique_conversation UNIQUE (buyer_id, seller_id, listing_title)
);

CREATE INDEX idx_threads_buyer ON public.threads(buyer_id, last_message_at DESC NULLS LAST);
CREATE INDEX idx_threads_seller ON public.threads(seller_id, last_message_at DESC NULLS LAST);

ALTER TABLE public.threads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view their threads"
  ON public.threads FOR SELECT TO authenticated
  USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

CREATE POLICY "Buyers can start threads"
  ON public.threads FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = buyer_id);

-- Allow participants to update last_message / last_message_at when sending
CREATE POLICY "Participants can update their threads"
  ON public.threads FOR UPDATE TO authenticated
  USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

-- MESSAGES
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID NOT NULL REFERENCES public.threads(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL,
  text TEXT NOT NULL CHECK (length(text) > 0 AND length(text) <= 2000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_messages_thread ON public.messages(thread_id, created_at);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Helper: is the current user a participant in this thread?
CREATE OR REPLACE FUNCTION public.is_thread_participant(_thread_id UUID, _user_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.threads
    WHERE id = _thread_id
      AND (_user_id = buyer_id OR _user_id = seller_id)
  )
$$;

CREATE POLICY "Participants can read messages"
  ON public.messages FOR SELECT TO authenticated
  USING (public.is_thread_participant(thread_id, auth.uid()));

CREATE POLICY "Participants can send messages"
  ON public.messages FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = sender_id
    AND public.is_thread_participant(thread_id, auth.uid())
  );

CREATE POLICY "Senders can delete their messages"
  ON public.messages FOR DELETE TO authenticated
  USING (auth.uid() = sender_id);

-- Trigger: bump thread.last_message / last_message_at on every new message
CREATE OR REPLACE FUNCTION public.bump_thread_on_message()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.threads
     SET last_message = NEW.text,
         last_message_at = NEW.created_at
   WHERE id = NEW.thread_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_bump_thread_on_message
AFTER INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.bump_thread_on_message();

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.threads;
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER TABLE public.messages REPLICA IDENTITY FULL;
ALTER TABLE public.threads REPLICA IDENTITY FULL;