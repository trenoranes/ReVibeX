REVOKE EXECUTE ON FUNCTION public.is_thread_participant(UUID, UUID) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.is_thread_participant(UUID, UUID) FROM anon;
REVOKE EXECUTE ON FUNCTION public.is_thread_participant(UUID, UUID) FROM authenticated;