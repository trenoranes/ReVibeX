import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

/**
 * Permanently delete the signed-in user's account and all associated data.
 *
 * Order matters: clean up storage and rows BEFORE deleting the auth user,
 * so we don't lose the userId we need to scope deletes by.
 */
export const deleteMyAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;

    // 1) Delete this user's listing photos from storage (folder = userId).
    try {
      const { data: files } = await supabaseAdmin.storage
        .from("listing-photos")
        .list(userId, { limit: 1000 });
      if (files && files.length) {
        await supabaseAdmin.storage
          .from("listing-photos")
          .remove(files.map((f) => `${userId}/${f.name}`));
      }
    } catch {
      // non-fatal — continue with row cleanup
    }

    // 2) Delete user-owned rows. Threads/messages cascade via participation
    //    rules but we explicitly clean what we own to be safe.
    await supabaseAdmin.from("saves").delete().eq("user_id", userId);
    await supabaseAdmin.from("listings").delete().eq("seller_id", userId);
    await supabaseAdmin
      .from("messages")
      .delete()
      .eq("sender_id", userId);
    await supabaseAdmin
      .from("threads")
      .delete()
      .or(`buyer_id.eq.${userId},seller_id.eq.${userId}`);
    await supabaseAdmin.from("user_roles").delete().eq("user_id", userId);
    await supabaseAdmin.from("profiles").delete().eq("id", userId);

    // 3) Finally remove the auth user. This also signs them out everywhere.
    const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
    if (error) throw new Error(error.message);

    return { ok: true };
  });
