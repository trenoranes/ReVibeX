import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useApp } from "@/context/AppContext";
import { TabBar } from "@/components/app/TabBar";
import { reviews } from "@/lib/mock-data";
import { Star, MapPin, Settings, Moon, LogOut, Bell, Shield, FileText, Edit3, X, Package, Trash2, ChevronRight, Loader2 } from "@/components/ui/icons";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { deleteMyAccount } from "@/server/account.functions";

export const Route = createFileRoute("/profile")({
  component: Profile,
});

function Profile() {
  const navigate = useNavigate();
  const { user, darkMode, toggleDark, logout, listings, deleteListing, markSold, isAuthed, isGuest, updateProfile } = useApp();
  const [editOpen, setEditOpen] = useState(false);
  const [tab, setTab] = useState<"listings" | "reviews">("listings");
  const [editName, setEditName] = useState(user.name);
  const [editLocation, setEditLocation] = useState(user.neighbourhood);
  const [editBio, setEditBio] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [deleting, setDeleting] = useState(false);
  const myListings = listings.filter((l) => l.seller.id === user.id);

  const handleDeleteAccount = async () => {
    if (deleteConfirm !== "DELETE") return;
    setDeleting(true);
    try {
      await deleteMyAccount();
      toast.success("Your account has been deleted");
      await logout();
      navigate({ to: "/" as string });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to delete account";
      toast.error(msg);
      setDeleting(false);
    }
  };

  if (isGuest || !isAuthed) {
    return (
      <div className="min-h-screen bg-background pb-24">
        <div className="mx-5 mt-20 rounded-3xl bg-gradient-hero p-8 text-center text-primary-foreground shadow-glow">
          <h2 className="font-display text-2xl font-bold">Make it yours</h2>
          <p className="mt-2 text-sm opacity-90">Create a profile to start posting, saving, and trading.</p>
          <button onClick={() => navigate({ to: "/auth" as string })} className="mt-6 rounded-full bg-primary-foreground px-6 py-3 text-sm font-bold text-secondary">Sign up free</button>
        </div>
        <TabBar />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-gradient-hero px-5 pb-8 pt-10 text-primary-foreground">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <img src={user.avatar} className="h-20 w-20 rounded-full border-4 border-primary-foreground/20 object-cover" alt="" />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-2xl font-bold">{user.name}</h1>
                {user.verified && <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold">✓</span>}
              </div>
              <p className="mt-1 flex items-center gap-1 text-xs opacity-80"><MapPin className="h-3 w-3" />{user.neighbourhood}, Halifax</p>
              <p className="mt-1 flex items-center gap-1 text-xs opacity-80"><Star className="h-3 w-3 fill-current" />{user.rating} · {user.sales} sales</p>
            </div>
          </div>
          <button onClick={() => setEditOpen(true)} className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-foreground/15 backdrop-blur hover:bg-primary-foreground/25"><Edit3 className="h-4 w-4" /></button>
        </div>

        <div className="mt-6 grid grid-cols-3 gap-3">
          <Stat label="Listed" value={myListings.length} />
          <Stat label="Sales" value={user.sales} />
          <Stat label="Followers" value={user.followers} />
        </div>
      </div>

      <div className="px-5 pt-5">
        <div className="flex gap-2 rounded-full bg-muted p-1">
          {(["listings", "reviews"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={cn("flex-1 rounded-full py-2 text-xs font-semibold capitalize transition-all", tab === t ? "bg-background shadow-soft" : "text-muted-foreground")}>
              {t === "listings" ? "My listings" : "Reviews"}
            </button>
          ))}
        </div>

        {tab === "listings" ? (
          myListings.length ? (
            <div className="mt-4 space-y-2">
              <Link to={"/my-listings" as string} className="flex items-center justify-between rounded-2xl border border-border bg-muted/50 px-3 py-2 text-xs font-semibold text-foreground hover:bg-muted">
                Manage all listings
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </Link>
              {myListings.slice(0, 5).map((l) => (
                <div key={l.id} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-2.5 shadow-soft">
                  <img src={l.photos[0]} alt="" className="h-16 w-16 rounded-xl object-cover" />
                  <div className="flex-1 min-w-0">
                    <p className="truncate font-semibold">{l.title}</p>
                    <p className="text-xs text-muted-foreground">{l.sold ? "Sold" : `$${l.price} · ${l.postedAt}`}</p>
                  </div>
                  <button onClick={() => navigate({ to: "/post" as string, search: { edit: l.id } as never })} className="flex h-8 w-8 items-center justify-center rounded-full text-foreground hover:bg-muted" aria-label="Edit"><Edit3 className="h-4 w-4" /></button>
                  {!l.sold && <button onClick={() => { markSold(l.id); toast.success("Marked sold ✓"); }} className="rounded-full bg-success px-3 py-1.5 text-[11px] font-bold text-success-foreground" aria-label="Mark sold"><Package className="h-3 w-3" /></button>}
                  <button onClick={() => { deleteListing(l.id); toast("Listing deleted"); }} className="flex h-8 w-8 items-center justify-center rounded-full text-destructive hover:bg-destructive/10" aria-label="Delete"><Trash2 className="h-4 w-4" /></button>
                </div>
              ))}
              {myListings.length > 5 && (
                <Link to={"/my-listings" as string} className="block rounded-2xl border border-dashed border-border bg-card py-3 text-center text-xs font-semibold text-primary hover:bg-muted">
                  See all {myListings.length} listings →
                </Link>
              )}
            </div>
          ) : (
            <div className="mt-10 text-center">
              <p className="text-sm text-muted-foreground">You haven't listed anything yet.</p>
              <Link to={"/post" as string} className="mt-3 inline-flex rounded-full bg-gradient-primary px-5 py-2.5 text-sm font-bold text-primary-foreground shadow-glow">
                Post your first item
              </Link>
            </div>
          )
        ) : (
          <div className="mt-4 space-y-2">
            {reviews.map((r) => (
              <div key={r.id} className="rounded-2xl border border-border bg-card p-4 shadow-soft">
                <div className="flex items-center gap-3">
                  <img src={r.avatar} className="h-10 w-10 rounded-full object-cover" alt="" />
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{r.reviewer}</p>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => <Star key={i} className={cn("h-3 w-3", i < r.rating ? "fill-primary text-primary" : "text-border")} />)}
                      <span className="ml-1 text-[11px] text-muted-foreground">{r.date}</span>
                    </div>
                  </div>
                </div>
                <p className="mt-2 text-sm">{r.text}</p>
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 space-y-1 rounded-2xl border border-border bg-card p-2 shadow-soft">
          <Row icon={<Moon className="h-4 w-4" />} label="Dark mode" right={<Toggle on={darkMode} onClick={toggleDark} />} />
          <Row icon={<Bell className="h-4 w-4" />} label="Notifications" onClick={() => toast("Push notifications enabled 🔔")} />
          <Row icon={<MapPin className="h-4 w-4" />} label="Location" sub={user.neighbourhood} onClick={() => toast("Location picker would open")} />
          <Row icon={<Settings className="h-4 w-4" />} label="Size preferences" onClick={() => toast("Size preferences modal")} />
          <Row icon={<FileText className="h-4 w-4" />} label="Terms & Privacy" onClick={() => toast("Opens legal pages")} />
          <Row icon={<Shield className="h-4 w-4" />} label="Boost a listing" sub="Coming soon" onClick={() => toast("Boost modal — coming soon ✨")} />
        </div>

        <button onClick={() => { logout(); navigate({ to: "/" as string }); }} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-destructive/30 bg-destructive/5 py-3 text-sm font-semibold text-destructive">
          <LogOut className="h-4 w-4" /> Log out
        </button>

        <button
          onClick={() => { setDeleteConfirm(""); setDeleteOpen(true); }}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl py-3 text-xs font-semibold text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="h-3.5 w-3.5" /> Delete account
        </button>
      </div>

      {editOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm sm:items-center" onClick={() => setEditOpen(false)}>
          <div className="w-full max-w-md animate-slide-up rounded-t-3xl bg-card p-6 shadow-card sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold">Edit profile</h2>
              <button onClick={() => setEditOpen(false)} className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-muted"><X className="h-4 w-4" /></button>
            </div>
            <div className="mt-4 space-y-3">
              <input value={editName} onChange={(e) => setEditName(e.target.value)} placeholder="Display name" className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary" />
              <input value={editLocation} onChange={(e) => setEditLocation(e.target.value)} placeholder="Neighbourhood" className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary" />
              <textarea value={editBio} onChange={(e) => setEditBio(e.target.value)} placeholder="Bio" rows={3} className="w-full resize-none rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary" />
              <button
                disabled={savingProfile}
                onClick={async () => {
                  setSavingProfile(true);
                  await updateProfile({
                    display_name: editName.trim(),
                    location: editLocation.trim() ? `${editLocation.trim()}, Halifax` : undefined,
                    bio: editBio.trim() || undefined,
                  });
                  setSavingProfile(false);
                  setEditOpen(false);
                  toast.success("Profile updated ✓");
                }}
                className="w-full rounded-full bg-gradient-primary py-3 text-sm font-bold text-primary-foreground shadow-glow disabled:opacity-60"
              >{savingProfile ? "Saving…" : "Save"}</button>
            </div>
          </div>
        </div>
      )}

      {deleteOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm sm:items-center" onClick={() => !deleting && setDeleteOpen(false)}>
          <div className="w-full max-w-md animate-slide-up rounded-t-3xl bg-card p-6 shadow-card sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-destructive">Delete account?</h2>
              <button disabled={deleting} onClick={() => setDeleteOpen(false)} className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-muted disabled:opacity-50"><X className="h-4 w-4" /></button>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">
              This permanently removes your profile, listings, photos, saves and messages. This cannot be undone.
            </p>
            <div className="mt-4">
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Type <span className="font-bold text-destructive">DELETE</span> to confirm
              </label>
              <input
                value={deleteConfirm}
                onChange={(e) => setDeleteConfirm(e.target.value)}
                disabled={deleting}
                placeholder="DELETE"
                className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-destructive disabled:opacity-50"
              />
            </div>
            <div className="mt-5 flex gap-2">
              <button
                disabled={deleting}
                onClick={() => setDeleteOpen(false)}
                className="flex-1 rounded-full border border-border bg-card py-3 text-sm font-semibold disabled:opacity-50"
              >Cancel</button>
              <button
                disabled={deleting || deleteConfirm !== "DELETE"}
                onClick={handleDeleteAccount}
                className="flex flex-1 items-center justify-center gap-2 rounded-full bg-destructive py-3 text-sm font-bold text-destructive-foreground disabled:opacity-40"
              >
                {deleting && <Loader2 className="h-4 w-4 animate-spin" />}
                {deleting ? "Deleting…" : "Delete forever"}
              </button>
            </div>
          </div>
        </div>
      )}

      <TabBar />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-primary-foreground/10 p-3 text-center backdrop-blur">
      <p className="font-display text-xl font-bold">{value}</p>
      <p className="mt-0.5 text-[10px] uppercase tracking-wider opacity-80">{label}</p>
    </div>
  );
}

function Row({ icon, label, sub, right, onClick }: { icon: React.ReactNode; label: string; sub?: string; right?: React.ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left hover:bg-muted">
      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted">{icon}</div>
      <div className="flex-1">
        <p className="text-sm font-medium">{label}</p>
        {sub && <p className="text-[11px] text-muted-foreground">{sub}</p>}
      </div>
      {right}
    </button>
  );
}

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <span onClick={(e) => { e.stopPropagation(); onClick(); }} className={cn("relative inline-flex h-6 w-11 cursor-pointer items-center rounded-full transition-colors", on ? "bg-primary" : "bg-border")}>
      <span className={cn("inline-block h-5 w-5 rounded-full bg-background shadow-soft transition-transform", on ? "translate-x-5" : "translate-x-0.5")} />
    </span>
  );
}
