import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useApp } from "@/context/AppContext";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Eye, EyeOff, Loader2 } from "@/components/ui/icons";
import { Logo } from "@/components/app/Logo";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  component: Auth,
});

function Auth() {
  const navigate = useNavigate();
  const { loginAsGuest } = useApp();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [acceptTos, setAcceptTos] = useState(false);
  const [loading, setLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState<"google" | "apple" | null>(null);
  const [errors, setErrors] = useState<{ email?: string; password?: string; tos?: string }>({});

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: typeof errors = {};
    if (!/^\S+@\S+\.\S+$/.test(email)) errs.email = "Enter a valid email";
    if (password.length < 6) errs.password = "Password must be 6+ characters";
    if (mode === "signup" && !acceptTos) errs.tos = "Please accept terms to continue";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setLoading(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/browse` },
        });
        if (error) throw error;
        // If email confirmation is required, session will be null
        if (!data.session) {
          toast.success("Account created — please verify your email ✉️");
          navigate({ to: "/verify-email", search: { email } });
        } else {
          toast.success("Welcome to ReVibeX! ✨");
          navigate({ to: "/browse" });
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        if (data.user && !data.user.email_confirmed_at) {
          await supabase.auth.signOut();
          toast.error("Please verify your email first.");
          navigate({ to: "/verify-email", search: { email } });
          return;
        }
        toast.success("Welcome back!");
        navigate({ to: "/browse" });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Authentication failed";
      toast.error(msg.includes("Invalid login") ? "Invalid email or password" : msg);
    } finally {
      setLoading(false);
    }
  };

  const oauth = async (provider: "google" | "apple") => {
    setOauthLoading(provider);
    try {
      const result = await lovable.auth.signInWithOAuth(provider, {
        redirect_uri: `${window.location.origin}/browse`,
      });
      if (result.error) {
        toast.error(`${provider === "google" ? "Google" : "Apple"} sign-in failed`);
        setOauthLoading(null);
        return;
      }
      if (result.redirected) return; // browser is redirecting
      // session set — go to browse
      toast.success("Signed in!");
      navigate({ to: "/browse" });
    } catch {
      toast.error("Sign-in failed");
    } finally {
      setOauthLoading(null);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-gradient-soft px-6 py-10">
      <div className="mx-auto w-full max-w-sm flex-1 flex flex-col">
        <div className="flex justify-center"><Logo size={36} /></div>

        <div className="mt-10 animate-fade-in">
          <h1 className="font-display text-3xl font-bold">{mode === "login" ? "Welcome back" : "Join the vibe"}</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            {mode === "login" ? "Sign in to keep buying, selling and trading." : "Sustainable fashion, one fit at a time."}
          </p>
        </div>

        {/* OAuth buttons */}
        <div className="mt-8 space-y-2.5">
          <button
            onClick={() => oauth("google")}
            disabled={!!oauthLoading || loading}
            className="flex w-full items-center justify-center gap-3 rounded-2xl border border-border bg-card py-3 text-sm font-semibold text-foreground shadow-soft transition hover:bg-muted disabled:opacity-60"
          >
            {oauthLoading === "google" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
              </svg>
            )}
            Continue with Google
          </button>

          <button
            onClick={() => oauth("apple")}
            disabled={!!oauthLoading || loading}
            className="flex w-full items-center justify-center gap-3 rounded-2xl border border-foreground bg-foreground py-3 text-sm font-semibold text-background shadow-soft transition hover:opacity-90 disabled:opacity-60"
          >
            {oauthLoading === "apple" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden>
                <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.53 4.08zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
              </svg>
            )}
            Continue with Apple
          </button>
        </div>

        <div className="mt-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-border" />
          <span className="text-xs uppercase tracking-wider text-muted-foreground">or email</span>
          <div className="h-px flex-1 bg-border" />
        </div>

        <form onSubmit={submit} className="mt-5 space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Email</label>
            <input
              type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              placeholder="you@dal.ca"
              className="w-full rounded-2xl border border-border bg-card px-4 py-3 text-sm shadow-soft outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
            />
            {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Password</label>
            <div className="relative">
              <input
                type={showPw ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-2xl border border-border bg-card px-4 py-3 pr-12 text-sm shadow-soft outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
              <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label="Toggle password">
                {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {errors.password && <p className="mt-1 text-xs text-destructive">{errors.password}</p>}
          </div>

          {mode === "login" && (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={async () => {
                  if (!email) { toast.error("Enter your email first"); return; }
                  const { error } = await supabase.auth.resetPasswordForEmail(email, {
                    redirectTo: `${window.location.origin}/reset-password`,
                  });
                  if (error) toast.error(error.message);
                  else toast.success("Reset link sent ✉️");
                }}
                className="text-xs font-medium text-primary hover:underline"
              >
                Forgot password?
              </button>
            </div>
          )}

          {mode === "signup" && (
            <label className="flex items-start gap-2 text-xs text-muted-foreground">
              <input type="checkbox" checked={acceptTos} onChange={(e) => setAcceptTos(e.target.checked)} className="mt-0.5 h-4 w-4 accent-[var(--color-primary)]" />
              <span>I accept the <a className="font-semibold text-primary underline">Terms</a> & <a className="font-semibold text-primary underline">Privacy Policy</a></span>
            </label>
          )}
          {errors.tos && <p className="-mt-2 text-xs text-destructive">{errors.tos}</p>}

          <button
            type="submit" disabled={loading || !!oauthLoading}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-primary py-3.5 text-sm font-bold text-primary-foreground shadow-glow transition-transform active:scale-[0.98] disabled:opacity-60"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>

        <button
          onClick={() => setMode(mode === "login" ? "signup" : "login")}
          className="mt-6 text-center text-sm text-muted-foreground"
        >
          {mode === "login" ? "New here?" : "Already a member?"}{" "}
          <span className="font-semibold text-primary">{mode === "login" ? "Create an account" : "Sign in"}</span>
        </button>

        <button
          onClick={() => { loginAsGuest(); navigate({ to: "/browse" }); }}
          className="mt-4 w-full rounded-full border border-border bg-card py-3 text-sm font-semibold text-foreground shadow-soft hover:bg-muted"
        >
          Continue as guest
        </button>

        <Link to="/" className="mt-6 text-center text-xs text-muted-foreground hover:text-foreground">← Back</Link>
      </div>
    </div>
  );
}
