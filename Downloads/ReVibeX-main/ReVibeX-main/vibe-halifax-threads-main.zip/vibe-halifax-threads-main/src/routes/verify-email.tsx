import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/app/Logo";
import { MailCheck, Loader2, LifeBuoy } from "@/components/ui/icons";
import { toast } from "sonner";

export const Route = createFileRoute("/verify-email")({
  validateSearch: (s: Record<string, unknown>) => ({
    email: typeof s.email === "string" ? s.email : "",
  }),
  component: VerifyEmail,
});

function VerifyEmail() {
  const navigate = useNavigate();
  const { email } = Route.useSearch();
  const [resending, setResending] = useState(false);
  const [checking, setChecking] = useState(false);

  // Poll for confirmation — when the user clicks the link in another tab,
  // their session updates here too.
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session?.user?.email_confirmed_at) {
        toast.success("Email verified! 🎉");
        navigate({ to: "/browse" });
      }
    });
    return () => subscription.unsubscribe();
  }, [navigate]);

  const resend = async () => {
    if (!email) { toast.error("Missing email"); return; }
    setResending(true);
    const { error } = await supabase.auth.resend({
      type: "signup",
      email,
      options: { emailRedirectTo: `${window.location.origin}/browse` },
    });
    setResending(false);
    if (error) toast.error(error.message);
    else toast.success("Verification email sent ✉️");
  };

  const checkNow = async () => {
    setChecking(true);
    const { data } = await supabase.auth.getUser();
    setChecking(false);
    if (data.user?.email_confirmed_at) {
      toast.success("Verified!");
      navigate({ to: "/browse" });
    } else {
      toast.message("Not verified yet — check your inbox.");
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-gradient-soft px-6 py-10">
      <div className="mx-auto w-full max-w-sm flex-1 flex flex-col">
        <div className="flex justify-center"><Logo size={36} /></div>

        <div className="mt-12 flex flex-col items-center text-center animate-fade-in">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/15 text-primary">
            <MailCheck className="h-8 w-8" />
          </div>
          <h1 className="mt-6 font-display text-2xl font-bold">Verify your email</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            We sent a confirmation link to{" "}
            <span className="font-semibold text-foreground">{email || "your inbox"}</span>.
            Click it to activate your account.
          </p>
        </div>

        <div className="mt-10 space-y-3">
          <button
            onClick={checkNow}
            disabled={checking}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-primary py-3.5 text-sm font-bold text-primary-foreground shadow-glow transition-transform active:scale-[0.98] disabled:opacity-60"
          >
            {checking && <Loader2 className="h-4 w-4 animate-spin" />}
            I've verified — continue
          </button>

          <button
            onClick={resend}
            disabled={resending}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border border-border bg-card py-3 text-sm font-semibold text-foreground shadow-soft hover:bg-muted disabled:opacity-60"
          >
            {resending && <Loader2 className="h-4 w-4 animate-spin" />}
            Resend email
          </button>

          <button
            onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/auth" }); }}
            className="w-full py-2 text-xs text-muted-foreground hover:text-foreground"
          >
            Use a different email
          </button>
        </div>

        <Link to="/auth" className="mt-8 text-center text-xs text-muted-foreground hover:text-foreground">← Back to sign in</Link>

        <div className="mt-6 rounded-2xl border border-border bg-card/60 p-4 text-center">
          <p className="text-xs font-semibold text-foreground">Trouble verifying?</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Didn't get the email or link not working? We're here to help.
          </p>
          <a
            href={`mailto:support@revix.app?subject=${encodeURIComponent("Email verification issue")}&body=${encodeURIComponent(`I'm having trouble verifying my email${email ? ` (${email})` : ""}.\n\nIssue:\n`)}`}
            className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline"
          >
            <LifeBuoy className="h-3.5 w-3.5" />
            Contact support
          </a>
        </div>
      </div>
    </div>
  );
}
