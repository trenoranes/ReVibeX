import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useApp } from "@/context/AppContext";
import { TabBar } from "@/components/app/TabBar";
import { ListingCard, ListingCardSkeleton } from "@/components/app/ListingCard";
import { Heart } from "@/components/ui/icons";

export const Route = createFileRoute("/saved")({
  component: Saved,
});

function Saved() {
  const { listings, saved } = useApp();
  const items = listings.filter((l) => saved.includes(l.id) && !l.sold);

  // Brief skeleton on mount so the list doesn't pop in
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 450);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="px-5 pb-3 pt-6">
        <h1 className="font-display text-3xl font-bold">Saved</h1>
        <p className="mt-0.5 text-sm text-muted-foreground">
          {loading ? "Loading your saves…" : `${items.length} item${items.length === 1 ? "" : "s"} you love`}
        </p>
      </header>

      {loading ? (
        <div className="grid grid-cols-2 gap-3 px-4">
          {Array.from({ length: 4 }).map((_, i) => <ListingCardSkeleton key={i} />)}
        </div>
      ) : items.length === 0 ? (
        <div className="mx-5 mt-12 rounded-3xl bg-gradient-soft p-10 text-center animate-fade-in">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-accent">
            <Heart className="h-7 w-7 text-primary" />
          </div>
          <p className="mt-4 font-display text-lg font-semibold">No saves yet</p>
          <p className="mt-1 text-sm text-muted-foreground">Tap the heart on any listing to save it here.</p>
          <Link to={"/browse" as string} className="mt-5 inline-block rounded-full bg-gradient-primary px-6 py-2.5 text-sm font-bold text-primary-foreground shadow-glow">Browse listings</Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 px-4 animate-fade-in">
          {items.map((l) => <ListingCard key={l.id} listing={l} />)}
        </div>
      )}
      <TabBar />
    </div>
  );
}
